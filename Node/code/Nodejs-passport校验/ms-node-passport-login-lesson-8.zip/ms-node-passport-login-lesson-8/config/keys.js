module.exports = {
    mongoURI:"mongodb+srv://test:test1234@cluster0-menjs.mongodb.net/test?retryWrites=true&w=majority"
}