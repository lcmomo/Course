项目介绍：身份验证登录应用
知识点：node.js & passport
难度：一般