lesson-2:创建mongoDB数据库


测试数据库地址
mongodb+srv://test:test1234@cluster0-menjs.mongodb.net/test?retryWrites=true&w=majority