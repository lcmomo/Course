项目介绍：node.js 自定义命令行界面
知识点：mongoDB数据库，mongoose，commander，inquirer


实现步骤：
Part-1: 引入模块，连接数据库，搭建用户信息架构 （mongoose）
Part-2: 实现添加用户，查找用户并进行测试 （commander，inquirer）
Part-3: 实现删除用户，更新用户，所有用户信息功能并进行测试 （commander，inquirer）
Part-4: 通过npm link对项目进行整体测试 （npm link）