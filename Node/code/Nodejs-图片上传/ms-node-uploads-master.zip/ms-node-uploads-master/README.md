项目介绍：图片上传应用
知识点：multer模块
中文文档地址：https://www.cnblogs.com/sexintercourse/p/11783741.html