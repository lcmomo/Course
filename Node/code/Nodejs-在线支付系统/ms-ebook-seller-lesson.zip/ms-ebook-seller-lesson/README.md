项目介绍：stripe API 实现 支付系统

stripe 注册地址：https://stripe.com/


初始化
npm install


<!-- stripe API 配置 -->
<!-- config文件夹下面keys_dev.js -->
module.exports={
    stripePublishableKey:'<你的测试公钥>',
    stripeSecretKey:'<你的测试私钥>'
}

