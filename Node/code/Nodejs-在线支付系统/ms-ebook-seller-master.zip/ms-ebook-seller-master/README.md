项目介绍：stripe API实现支付系统

stripe注册地址：https://stripe.com/

初始化
npm install