# yd-vue3demo-code

## Project setup
```
yarn install
```

### Compiles and hot-reloads for development
```
yarn serve
```

### Compiles and minifies for production
```
yarn build
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).

1.Vue3还没有正式发版？
正式发版 适应。切过去到Vue3
2.@vue/composition-api 语言 dom diff机制vue2
3.TypeScript + Vuex生态 自己代码量相对较多
4.nw.js exe 
  uni-app ios
5.大厂面试 TypeScript + 原理 async await -> tsc

6.Vuex 状态的变化 
  Vue3 ref + reactive 创建一个响应式的代码
        inject  + provide 
  实现一个简单版本Vuex 
Vuex 对Vue3 适配

7.React useState + useReducer +  provider = redux(适配入职Facebook)
状态管理机制 mobx-react-lite

Node.js + TypeScript + React/Vue + Webapck + CI/CD + SDK + CSS NEXT 20k MPA 互转 SPA  


