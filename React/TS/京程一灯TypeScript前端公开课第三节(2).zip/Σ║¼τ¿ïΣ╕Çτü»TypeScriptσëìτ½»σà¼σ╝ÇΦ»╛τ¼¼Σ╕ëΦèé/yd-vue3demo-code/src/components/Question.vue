<template>
  <div>
    <h1 @click="increment">{{x}}</h1>
    <hr />
    <h2>vuex中的值🐻,{{loading}}</h2>
    <el-table :data="tableData" border style="width: 100%">
      <el-table-column prop="date" label="日期" width="180"></el-table-column>
      <el-table-column prop="name" label="姓名" width="180"></el-table-column>
      <el-table-column prop="address" label="地址"></el-table-column>
    </el-table>
  </div>
</template>

<script lang="ts">
import {
  defineComponent,
  ref,
  reactive,
  Ref,
  onMounted,
  computed,
  watchEffect
} from "@vue/composition-api";
import { useMousePosition } from "@/components/hooks/QuestionHook";
import { useState, useActions } from "vuex-composition-helpers";
import * as store from "@/store";
interface ItableData {
  date: string;
  name: string;
  address: string;
}
interface Iprops {
  articleId: String;
}
export default defineComponent({
  name: "Question",
  props: {
    articleId: String
  },
  setup(props: Iprops, { root }) {
    console.log("⏰上下文", root.$zhijia);
    const { x, y } = useMousePosition();
    const tableData: Ref<ItableData[]> = ref([]);
    const { getData } = useActions(['getData']);
    const { loading } = useState(['loading']);
    // const flag: Ref<boolean> = ref(root.$store.state.loading);
    // const flag = computed(() => root.$store.state.loading);
    console.log("🐻", x);
    const increment = () => {
      x.value += 2;
      getData();
      // root.$store.dispatch("getData");
    };
    // watchEffect(()=>{})
    onMounted(() => {
      setTimeout(() => {
        tableData.value = [
          {
            date: "2016-05-02",
            name: "王小虎",
            address: "上海市普陀区金沙江路 1518 弄"
          },
          {
            date: "2016-05-04",
            name: "王小虎",
            address: "上海市普陀区金沙江路 1517 弄"
          },
          {
            date: "2016-05-01",
            name: "王小虎",
            address: "上海市普陀区金沙江路 1519 弄"
          },
          {
            date: "2016-05-03",
            name: "王小虎",
            address: "上海市普陀区金沙江路 1516 弄"
          }
        ];
      });
    });
    return {
      x,
      loading,
      tableData,
      increment
    };
  }
});
</script>
