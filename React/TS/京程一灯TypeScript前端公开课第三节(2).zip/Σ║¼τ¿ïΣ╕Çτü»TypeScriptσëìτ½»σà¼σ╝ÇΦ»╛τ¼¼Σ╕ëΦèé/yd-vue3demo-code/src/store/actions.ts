import { ActionContext } from 'vuex'
import { moduleState } from "./constant";
const moduleGetters = {};
type State = typeof moduleState;
// type Geters = typeof moduleGeters;
type ReturnGetters<T extends { [key: string]: (...args: any) => any }> = {
    [P in keyof T]: ReturnType<T[P]>
}
type Geters = ReturnGetters<typeof moduleGetters>;
export default {
    "getData"({ commit }: ActionContext<State, Geters>) {
        commit("getData",false);
    }
}