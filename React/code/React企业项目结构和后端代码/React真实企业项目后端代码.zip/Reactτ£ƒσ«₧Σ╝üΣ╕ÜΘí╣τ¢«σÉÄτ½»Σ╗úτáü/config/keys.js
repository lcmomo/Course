module.exports = {
  mongoURI: 'mongodb://test:test1234@ds223756.mlab.com:23756/mervn-api',
  secretOrKey: 'secret'
};
