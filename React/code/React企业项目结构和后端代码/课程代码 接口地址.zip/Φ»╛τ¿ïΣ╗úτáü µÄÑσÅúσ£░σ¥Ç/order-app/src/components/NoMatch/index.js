import React from 'react';

export default function index({ status }) {
  return <div>{status} 浏览器地址不存在,请确认地址是否正确</div>;
}
