export default {
  namespace: 'home',

  state: {
    text: 'this is the home component'
  },

  subscriptions: {},

  effects: {},

  reducers: {}
};
