import React, { Component } from 'react';

export default class index extends Component {
  render() {
    return <div>历史订单</div>;
  }
}
