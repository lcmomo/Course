import React, { Component } from 'react';

export default class index extends Component {
  render() {
    return <div>点餐稳定</div>;
  }
}
