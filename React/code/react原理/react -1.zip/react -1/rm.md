从0到1 react


8:05  开始

框架 ？？    浏览器 

flutter  dart
js --> v8/quickjs  js

浏览器  js/html/css ==框架 

react UI ==> 配合浏览器的特性 做开发   压榨

react / 环境合作 ==>react js 引擎  
1. 浏览器 架构 实现 
2. 浏览器特点--> 契合 框架（~=压制） 性能 --> 浏览器特点
3. 框架各个细节





浏览器：
    1. 浏览器进程 
         ui线程 
         网络线程 dns (跨域检查) MIME
         文件线程
    2. 渲染进程
        合成线程
        主线程
            Layer  层叠上下文
            https://developer.mozilla.org/zh-CN/docs/Web/CSS/CSS_Positioning/Understanding_z_index/The_stacking_context
            BFC 

            paint 绘制记录表 (先绘制一个三角形、再绘制一个)；
            光栅化 无数个像素点   CPU(几何数据 长款、位置)==>GPU  (块里面所有像素点的信息集合)
            


            30 50 
            0,0

            10 10 
            合成线程
            {
                (几何数据 长款、位置) ：(块里面所有像素点的信息集合，内存地址)
            }
        tile work线程


        react 17 < ==> document  
            事件 >


        不要有感慨，要有具体的信息，具体做什么？

        知识吸毒 

        提出问题 + 实践 + 总结
    3. GPU进程
