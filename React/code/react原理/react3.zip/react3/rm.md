长任务--> 小任务 

react ==>js  
管理数据 

js  任务中断   await yeild    




https://facebook.github.io/regenerator/


```js
       let nextUnitOfwork=null; //定义下一次要处理的小任务

        //每一次浏览器有时间的时候，内部做的事情
        function workLoop(deadline){
            //不断判断是否还有时间执行
            let shouldYield=false;
        
            //和上边一样，开始一个循环
            //首先是判断是否应该暂停，并且还要判断是否有下一次需要执行的任务
            while(!shouldYield&&nextUnitOfwork){
                //这个里面就应该执行对应的任务了
                //并且我们上边说了，在执行小任务的时候，它是和其他小任务有关联的
                //所以我们应该找出下一次可以执行的任务；
                    nextUnitOfwork=performUnitOfWork(nextUnitOfwork);
                    
                //每一次执行完任务之后，都应该判断是否应该暂停
                shouldYield=deadline.timRemaining()<1;
            }
                
                //在当前次循环退出前，注册下一次的任务
            requestIdleCallback(workLoop);
        }

        //第一次执行js的时候，就开始调度每一次有时间的时候就做一个小任务
        requestIdleCallback(workLoop);



        function performUnitOfWork(nextUnitOfwork){
            //执行当前次任务，并且需要返回下一次的任务；

        }


```



requestAnimtionFrame  ==>  requestIdleCallback  



5ms 


react ???   任务维度    ==> ui 


react 数据   ==》 UI   ==> 

任务小任务颗粒    数据到UI的过程 执行的小任务    


jsx  ==> 视图  

js  fiber    ==> PCB 

fiber  


树 ==》


孩子兄弟表示法





libuv     skia     v8 quickjs (js)  >浏览器之外的js渲染引擎  


html css  





孩子兄弟表示法   


return sibling  child




a={
    children:[b,c,d]
}


a={
    child:b
}


b={
    sibling:c
}



 React.createElement   元素结构 

 fiber 关系  运行时 数据


 小任务？？ 
    构建当前节点的fiber以及关联对应的他与父fiber和子fiber的关系
    createElement   obj ==》fiber 关系链 （可中断，回复的位置）





react深入理解   



js   ==> v8 不中断 main   


契合浏览器框架   ==> v8 (js引擎) 


v8 quickjs  ==>   libuv (事件调度)    skia 

flutter (js/dart)  ==> skia 

浏览器 js(canvas) => skia 



不卡顿 渲染频率==>执行事件时间少 

dom操作 长任务 js  ==> 可中断机制  ==> yeild PCB



问题
1. 每一层的dom对象的创建和插入  遍历

dom 创建 插入  遍历 （可中断）

dom==>树结构 
可中断 可恢复  继续执行 ？？==> 中断节点特征> 中断节点与其他节点的关联关系 


1. 创建dom、插入dom 、遍历dom  ==> 可以恢复的数据结构（fiber）






不断查找是否还有任务执行(多个任务==>哪一个任务（优先级调度）)  ==> 调度（schedule） 



render (同步)\setState\forceUpdate 

requestIdleCallback！！     requestAnimationFrame(5ms 多个小任务)

选择出来要执行的任务 ==> 
performUnitOfWork
1. 创建本节点的dom结构 
    创建本节点的子fiber（他们之间的关系）

render 

     创建当前fiber的dom节点，创建与子fiber节点的关系链，找出下一个小任务的fiber

    RootFiber   placement
    ```html
     <div id="foo"><a>bar</a><b></b></div>
    ```
update
    找出更新（jsx element(本次更新）  vs fiber(当前页面)）

    队列[ 哪个fiber，做了那个修改]

    协调（reconcile）



<!-- hooks    -->



