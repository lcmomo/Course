const data: string = '京程一灯';
console.log(data);
