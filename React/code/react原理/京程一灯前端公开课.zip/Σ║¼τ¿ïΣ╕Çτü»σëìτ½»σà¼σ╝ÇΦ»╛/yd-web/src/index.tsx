import React, { FC } from 'react';
type Data = {
  age: number;
};
const App: FC<Data> = (): JSX.Element => {
  //
};

interface Window {
  laoyuan: 123;
}
