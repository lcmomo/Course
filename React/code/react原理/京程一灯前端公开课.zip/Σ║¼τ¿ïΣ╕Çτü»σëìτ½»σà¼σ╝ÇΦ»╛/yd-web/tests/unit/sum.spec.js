test('京程一灯测试脚本', () => {
  expect(1 + 1).toEqual(2);
});
