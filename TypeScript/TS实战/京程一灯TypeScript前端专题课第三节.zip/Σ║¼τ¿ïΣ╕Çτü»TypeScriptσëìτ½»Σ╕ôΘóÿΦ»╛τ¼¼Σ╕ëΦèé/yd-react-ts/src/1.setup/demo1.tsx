// import * as React from 'react';
// import * as ReactDOM from 'react-dom';
// tsconfig.json 未来的代码 及时的有一个的开发环境
// allowSyntheticDefaultImports 就可以省略掉这个*了
// 不建议使用esModuleInterop
import React from 'react';
import ReactDOM from 'react-dom';
