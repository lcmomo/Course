import user from './modules/user';
const modules = {
  user,
};
export { modules };
