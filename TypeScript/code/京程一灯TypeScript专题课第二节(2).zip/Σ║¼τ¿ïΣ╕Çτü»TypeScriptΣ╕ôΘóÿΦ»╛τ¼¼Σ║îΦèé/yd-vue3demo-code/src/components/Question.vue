<template>
  <div>
    <h1 @click="increment">{{x}}</h1>
    <hr />
    <h2>vuex中的值,{{flag}}</h2>
    <el-table :data="tableData" border style="width: 100%">
      <el-table-column prop="date" label="日期" width="180"></el-table-column>
      <el-table-column prop="name" label="姓名" width="180"></el-table-column>
      <el-table-column prop="address" label="地址"></el-table-column>
    </el-table>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref, Ref, onMounted } from "@vue/composition-api";
import { useMousePosition } from "@/components/hooks/QuestionHook";
import * as store from "@/store";
interface ItableData {
  date: string;
  name: string;
  address: string;
}
export default defineComponent({
  name: "Question",
  setup(props,context) {
    console.log("上下文",context);
    const { x, y } = useMousePosition();
    const tableData: Ref<ItableData[]> = ref([]);
    const flag: Ref<boolean> = ref(true);
    // flag.value = store.default.state.loading;
    console.log("🐻", x);
    const increment = () => {
      x.value += 2;
      store.default.dispatch("getData");
      flag.value = store.default.state.loading;
      // store.default.state.loading = false;
    };
    onMounted(() => {
      setTimeout(() => {
        tableData.value = [
          {
            date: "2016-05-02",
            name: "王小虎",
            address: "上海市普陀区金沙江路 1518 弄"
          },
          {
            date: "2016-05-04",
            name: "王小虎",
            address: "上海市普陀区金沙江路 1517 弄"
          },
          {
            date: "2016-05-01",
            name: "王小虎",
            address: "上海市普陀区金沙江路 1519 弄"
          },
          {
            date: "2016-05-03",
            name: "王小虎",
            address: "上海市普陀区金沙江路 1516 弄"
          }
        ];
      });
    });
    return {
      x,
      flag,
      tableData,
      increment
    };
  }
});
</script>
