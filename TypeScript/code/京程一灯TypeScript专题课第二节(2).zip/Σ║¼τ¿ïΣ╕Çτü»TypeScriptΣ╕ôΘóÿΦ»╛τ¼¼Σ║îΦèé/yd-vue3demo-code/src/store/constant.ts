const moduleState = {
    loading: true
}
export { moduleState }