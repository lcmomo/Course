// const useHelloWorld = (initialCount) :useHelloWorldIntl=> {
// }
// useHelloWorld.increment = (count)=>{
//     const increment = () => {
//         count.value++;
//       };
// }
const useHelloWorld = () => {}
export {
    useHelloWorld
}
