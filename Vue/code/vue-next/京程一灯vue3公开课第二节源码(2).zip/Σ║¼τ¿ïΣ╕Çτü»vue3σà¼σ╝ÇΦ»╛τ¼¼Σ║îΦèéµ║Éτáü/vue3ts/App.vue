<template>
    <div>
        <h1 onlcik>{{number}}</h1>
    </div>
</template>
<script>
import App from "./App";
import {reactive ,watch,toRefs} from "@vue/compoition-api";
export default {
    setup(){
        //初始化数据 + watch的点 需要的函数 基于函数式编程的方式
        const state = reactive({
            number:20
        })
        return {
            ...toRefs(state)
        };
    }
}
</script>