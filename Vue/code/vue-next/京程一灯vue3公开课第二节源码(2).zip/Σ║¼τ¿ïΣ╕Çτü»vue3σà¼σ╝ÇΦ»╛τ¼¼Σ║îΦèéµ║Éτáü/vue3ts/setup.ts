interface IProps{
    name:string
}
const MyComponent = {
  setup(props:IProps) {
    return {
      msg: `hello ${props.name}!`
    }
  },
  template: `<div>{{ msg }}</div>`
}