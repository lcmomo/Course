package com.way.service;

public class UserLogin {
	private void syso() {
		// TODO Auto-generated method stub

	}
}
