import { name, } from "./info.js";
// const { name } = require('./info')
// var a = 1
function setName() {
    console.log(name)
}
setName();