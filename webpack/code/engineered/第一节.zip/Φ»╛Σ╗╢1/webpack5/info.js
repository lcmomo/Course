export var name = 'yideng';
// export class yideng {
//     constructor() {
//         this.a = 'laiba'
//     }
// }
// module.exports = {
//     name,
//     yideng
// };